-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Mar 29, 2022 at 02:51 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `storyproj`
--

-- --------------------------------------------------------

--
-- Table structure for table `cms_category`
--

DROP TABLE IF EXISTS `cms_category`;
CREATE TABLE IF NOT EXISTS `cms_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cms_category`
--

INSERT INTO `cms_category` (`id`, `name`) VALUES
(1, 'Fairy Tales'),
(2, 'Comedy'),
(3, 'Animals'),
(4, 'Tragedy'),
(5, 'People');

-- --------------------------------------------------------

--
-- Table structure for table `cms_posts`
--

DROP TABLE IF EXISTS `cms_posts`;
CREATE TABLE IF NOT EXISTS `cms_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `message` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `status` enum('published','draft','archived','') NOT NULL DEFAULT 'published',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cms_posts`
--

INSERT INTO `cms_posts` (`id`, `title`, `message`, `category_id`, `userid`, `status`, `created`, `updated`) VALUES
(1, 'Meet the Sheldricks ', 'When you have a crazy, rather insane family, introducing them to the person of your dreams isn’t the smartest idea. Too bad my siblings never actually give me a choice.\r\n\r\nIt’s hard to describe this one, and I don’t want to give too much away as it’s better to go in without knowing much. But I will say that it’s about 18-year-old Lettie Sheldrick, who has a huge number of cousins and siblings. Their antics spice up her dating life as she attempts to go out with Brandon McArthur, who she’s worried is far too normal to deal with her family. The story is bloody funny and remarkably unique.', 3, 1, 'published', '2022-03-14 10:07:15', '2022-03-14 17:55:56'),
(3, 'To Defend or Fall ', 'When rivalry takes action, students at Westfield School of Boarding–fondly known as SOB–must choose sides. The ringleaders are thrilled, until their war becomes a war to protect the very school they hate. \r\n\r\nA very madcap story. Not exactly unfinished, but not exactly finished either. Ember, a self-declared Ice Queen, attends an isolated boarding school with her arch-nemesis Cale. What begins as a series of pranks intended to one-up each other quickly spirals into something more, involving all their classmates in a battle to save their school.\r\n', 2, 4, 'published', '2022-03-14 15:06:11', '2022-03-29 01:21:36'),
(4, 'Just Like a Fruitcake', 'I said hi. He said he’d eat my eyeballs. I said to put his goggles on. He said he raped my cat. I said he’s a cannibal Saiyan. He said he’s a colourblind vampire. The psychic said we’d be gushing over each other by next year. Someone’s lying.\r\n\r\nThis is a Twilight parody! So ignore the super-weird blurb, because it is meant to be very ridiculous and not taken seriously. Heroine Violet runs into Derek, who’s from a family of vampires, only be turns out to be certifiably insane. Too bad she keeps getting thrown into his company.\r\n\r\nThis author wrote some absolutely amazing stories before taking them down, and Just Like a Fruitcake is the only one left. A tragedy, because their story ‘Dear Imagination’ is unforgettably excellent.', 1, 2, 'draft', '2022-03-15 05:06:39', '2022-03-15 08:41:29'),
(17, 'The Champagne Gang ', '\r\n“Does that kiss have anything to do with why we’re on a train to New York in the middle of the night?”\r\n\r\nWell-written and complex. FictionPress at its best. After the death of her half-brother, Summer Ward and her family move to a new town; at Thornton Academy, she gets sucked into a friendship group with its own intense problems. One of the biggest is Zach Gellar, a mysterious loner with broken relationships with her new friends.\r\n', 5, 5, 'published', '2022-03-28 21:29:28', '2022-03-28 21:29:28'),
(18, 'I Only Date Nerds ', 'I have rules when it comes to who I’ll date, and he wants me to break every single one.\r\n\r\nFull disclosure, this is unfinished and hasn’t been updated since 2008. Yes, that’s 13 years, and yes, that’s a hell of a long time. But it’s so bloody funny that I don’t even care, because what does exist is absolute gold.\r\n\r\nIndy loves nerds. More specifically, she’s crushing on Wally (real name: Tristan), one of her classmates, whose argyll jumpers and retainers embody the nerd aesthetic. Weirdly, he’s not biting. So she enlists the help of his brother Cole, the school bad boy, to catch Wally. Weirdly, Cole’s advice isn’t very effective…\r\n', 5, 4, 'published', '2022-03-29 01:22:57', '2022-03-29 01:22:57');

-- --------------------------------------------------------

--
-- Table structure for table `cms_user`
--

DROP TABLE IF EXISTS `cms_user`;
CREATE TABLE IF NOT EXISTS `cms_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cms_user`
--

INSERT INTO `cms_user` (`id`, `first_name`, `last_name`, `email`, `password`, `type`, `deleted`) VALUES
(1, 'Admin', '', 'admin@rgu.com', '202cb962ac59075b964b07152d234b70', 1, 0),
(2, 'Authur', '', 'user@rgu.com', '202cb962ac59075b964b07152d234b70', 2, 0),
(4, 'Johnny', 'Olayinka', 'john@rgu.com', '6fbeb32bd80a77d46d29eefb4b895c50', 2, 0),
(5, 'Azeez', 'Yusuf', 'azeez@rgu.com', '6fbeb32bd80a77d46d29eefb4b895c50', 1, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
