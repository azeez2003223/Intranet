<link href="css/style.css" rel="stylesheet" id="bootstrap-css">
</head>
<body class="">
<div role="navigation" class="navbar navbar-default navbar-static-top" style="background-color: white;">
      <div class="container" style="background-color: white;">
        <div class="navbar-header">
          <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <img src="../logo.jpg" height="75" width="75"/>
        </div>

        <div style="font-weight: bold; color: #6c0d25; padding-top: 20px; padding-left: 20px; background-color: #ffffff;">
        <a href="#" class="navbar-brand" style="color: #6c0d25; ">Scotland Tourism Organization</a></div>

        <div style="background-color: #7B96CD; float: left;">
        <div style="background-color: #7B96CD; width: 750px; ">
          <ul class="nav navbar-nav header-right">
            <li><a href="../index.php" style="color: white">Home</a></li>
            <li><a href="#about" style="color: white">About Us</a></li>
            <li><a href="#" style="color: white">Login</a></li>
            <li><a href="#" style="color: white">Contact Us</a></li>
           
          </ul></div>
         
        </div><!--/.nav-collapse  rgb(0,0,255)-->
      </div>
    </div>
	
	<div class="container" style="min-height:500px;">
	